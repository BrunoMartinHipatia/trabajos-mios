
let nombre='pepe'
const lastname= 'viyuela'
console.log("hola "+ nombre + ' '+ lastname );
const condicion = true;

if(condicion){
    let nombre ='ale'
    console.log("hola "+ nombre + ' '+ lastname );
    
}
console.log(`hola ${nombre} lastname` );