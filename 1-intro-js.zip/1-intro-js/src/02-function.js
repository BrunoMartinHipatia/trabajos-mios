const sayHello =(nombre  ='Pepe' , age = 2) => `hola  ${nombre} tengo ${age} años` 
const add = (a=2, b =3) => a+b

const prueba = add()
console.log(add())
console.log(sayHello())