
export const Title = ({title}) => {
    return <h1>{title}</h1>;
}