export const loginUser = ({username, password})=>{
return (username === 'admin' && password ==='12345');
}